package org.tacademy.inflation;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

/**
 * Created by Tacademy on 2015-03-09.
 */
public class SubFragment extends Fragment {
    SubFragmentListener listener;

    int number;
    String name;
    int imageId;

    public static interface SubFragmentListener {
        public void onItemClick(String data);
    }

    public static SubFragment newInstance(int number, String name, int imageId) {
        SubFragment fragment = new SubFragment();

        Bundle args = new Bundle();
        args.putInt("number", number);
        args.putString("name", name);
        args.putInt("imageId", imageId);

        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onAttach(Activity activity) {
        Toast.makeText(getActivity(), "onAttach() 호출됨.", Toast.LENGTH_LONG).show();

        listener = (SubFragmentListener) activity;

        super.onAttach(activity);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Toast.makeText(getActivity(), "onCreate() 호출됨.", Toast.LENGTH_LONG).show();

        Bundle bundle = getArguments();
        number = bundle.getInt("number");
        name = bundle.getString("name");
        imageId = bundle.getInt("imageId");

        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Toast.makeText(getActivity(), "onCreateView() 호출됨.", Toast.LENGTH_LONG).show();

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.sublayout, container, false);

        ImageView imageView = (ImageView) rootView.findViewById(R.id.imageView);
        if (imageId != 0) {
            imageView.setImageResource(imageId);
        }

        Button button2 = (Button) rootView.findViewById(R.id.button2);
        if (name != null) {
            button2.setText(name);
        }

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick("안녕하세요.");
                }
            }
        });

        return rootView;
    }

    @Override
    public void onDestroy() {
        Toast.makeText(getActivity(), "onDestroy() 호출됨.", Toast.LENGTH_LONG).show();

        super.onDestroy();
    }

    @Override
    public void onDetach() {
        Toast.makeText(getActivity(), "onDetach() 호출됨.", Toast.LENGTH_LONG).show();

        listener = null;

        super.onDetach();
    }

    @Override
    public void onDestroyView() {
        Toast.makeText(getActivity(), "onDestroyView() 호출됨.", Toast.LENGTH_LONG).show();

        super.onDestroyView();
    }
}
