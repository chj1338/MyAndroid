package org.tacademy.inflation;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;


public class MainActivity extends ActionBarActivity implements SubFragment.SubFragmentListener {
    LinearLayout container;
    LinearLayout container2;
    EditText editText;

    SubFragment fragment;
    SubFragment2 fragment2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        container = (LinearLayout) findViewById(R.id.container);
        container2 = (LinearLayout) findViewById(R.id.container2);

        editText = (EditText) findViewById(R.id.editText);

    }

    public void onButton1Clicked(View v) {
        //fragment = new SubFragment();
        fragment = SubFragment.newInstance(1, "첫화면", R.drawable.person);

        fragment2 = new SubFragment2();

        FragmentManager manager = getSupportFragmentManager();
        manager.beginTransaction().replace(R.id.container, fragment).commit();
        manager.beginTransaction().replace(R.id.container2, fragment2).commit();


        /*
        SubLayout view = new SubLayout(this);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);

        container.addView(view, params);
        */

    }

    @Override
    public void onItemClick(String data) {
        editText.setText(data);

        fragment2.onData(data);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
